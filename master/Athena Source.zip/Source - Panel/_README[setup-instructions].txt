1. Open up config.php and input the credentials of your MySql database.
2. Import 'dump.sql' to your MySql database.
3. Upload all of the files in this folder to a webserver.
4. Visit the file 'importgeoip.php' from your webbrowser, and leave it to load. It may take up to a few minutes.
5. The default login credentials are root:toor. Log into your panel and navigate to 'User Management' to
	create a new login for yourself, or navigate to 'Preferences' if you wish to change your password.

NOTE: Be sure to rename the directory 'panel' if you specified a directory other than that.